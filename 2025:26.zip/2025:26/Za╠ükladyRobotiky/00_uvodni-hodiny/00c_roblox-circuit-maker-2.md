# 00c: Roblox Circuit Maker 2 – vizuální obvody (říjen)

## Cíle hodiny
- Zažít stavbu obvodů v interaktivní hře a přenést principy do reality.

## Materiály
- Roblox účet a hra Circuit Maker 2.
- Projektor, checklist úkolů.

## Průběh hodiny (45–60 min)
1. **Tutorial a ovládání** (10 min)
2. **Úkoly: postavit logickou bránu, řetězec s časováním** (20–25 min)
3. **Reflexe: kde je vstup, výstup, napájení?** (5–10 min)

## Domácí úkol
- Dokončit alespoň dva levely doma a přinést poznámky, co bylo nejtěžší.


