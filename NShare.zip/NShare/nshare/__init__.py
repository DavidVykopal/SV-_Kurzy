"""NShare package initializer."""

__all__ = []
