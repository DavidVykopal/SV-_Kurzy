"""HTTP server implementation for NShare."""

from __future__ import annotations

import cgi
import json
import logging
import mimetypes
import threading
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler
from pathlib import Path
from shutil import copyfileobj
from typing import Optional
from urllib.parse import parse_qs, unquote, urlparse

from .config import Config
from .security import require_token
from .storage import Storage
from .utils import get_lan_ip, sanitize_filename
from . import views


class NShareRequestHandler(SimpleHTTPRequestHandler):
    server_version = "NShare/1.0"

    def __init__(self, *args, **kwargs):
        self.config: Config = kwargs.pop("config")
        self.storage = Storage(self.config.root_path, hide_hidden=self.config.hide_hidden)
        self.static_root = (Path(__file__).resolve().parent / "static").resolve()
        super().__init__(*args, directory=str(self.config.root_path), **kwargs)

    def translate_path(self, path: str) -> str:
        original = Path(url_to_path(path))
        try:
            resolved = self.storage.open_file(original)
        except FileNotFoundError:
            return super().translate_path(path)
        return str(resolved)

    def log_message(self, format: str, *args) -> None:
        logging.info("%s - %s", self.address_string(), format % args)

    def get_token_from_request(self) -> Optional[str]:
        return self._query_params().get("token")

    def _send_html(self, body: str, status: HTTPStatus = HTTPStatus.OK) -> None:
        body_bytes = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body_bytes)))
        self.end_headers()
        self.wfile.write(body_bytes)

    @require_token(lambda self: self.config.auth_token)
    def do_GET(self):
        target = Path(url_to_path(self._query_params().get("path", "")))

        if self.path.startswith("/static/"):
            return self._serve_static()

        if self.path.startswith("/api/list"):
            return self._handle_api_list(target)

        if self.path.startswith("/download"):
            return self._handle_download(target)

        if self.path.startswith("/upload") and self.command == "GET":
            if not self.config.allow_upload:
                self.send_error(HTTPStatus.FORBIDDEN, "Uploads disabled")
                return
            body = views.render_upload_form(target)
            self._send_html(body)
            return

        try:
            items = list(self.storage.list(target))
        except (FileNotFoundError, ValueError):
            self.send_error(HTTPStatus.NOT_FOUND, "Path not found")
            return
        body = views.render_index(target, items, self.config.allow_upload, self.config.auth_token is not None)
        self._send_html(body)

    @require_token(lambda self: self.config.auth_token)
    def do_POST(self):
        if not self.config.allow_upload:
            self.send_error(HTTPStatus.FORBIDDEN, "Uploads disabled")
            return

        if not self.path.startswith("/upload"):
            self.send_error(HTTPStatus.NOT_FOUND)
            return

        content_type = self.headers.get("Content-Type")
        if not content_type:
            self.send_error(HTTPStatus.BAD_REQUEST, "Missing Content-Type")
            return

        ctype, pdict = cgi.parse_header(content_type)
        if ctype != "multipart/form-data":
            self.send_error(HTTPStatus.BAD_REQUEST, "Unsupported Content-Type")
            return

        boundary = pdict.get("boundary")
        if not boundary:
            self.send_error(HTTPStatus.BAD_REQUEST, "Missing multipart boundary")
            return

        target = Path(self._query_params().get("target", ""))
        saved_files = []
        total_size = 0

        for headers, content in parse_multipart(self.rfile, boundary.encode(), self.headers):
            disposition = headers.get("Content-Disposition", "")
            if "filename=" not in disposition:
                if "name=\"target\"" in disposition:
                    target_str = content.decode("utf-8", errors="ignore").strip()
                    target = Path(target_str)
                continue
            filename = extract_filename(disposition)
            if not filename:
                continue
            sanitized = sanitize_filename(filename)
            if not sanitized:
                continue
            if self.config.allowed_extensions is not None:
                ext = Path(sanitized).suffix.lower().lstrip(".")
                if ext not in self.config.allowed_extensions:
                    continue
            data = content
            total_size += len(data)
            if total_size > self.config.max_upload_size:
                self.send_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "Upload too large")
                return
            saved_files.append((target / sanitized, io.BytesIO(data)))

        for relative, buffer in saved_files:
            temp_file = self.config.root_path / ".__upload.tmp"
            with temp_file.open("wb") as fh:
                fh.write(buffer.getvalue())
            self.storage.save_file(relative, temp_file)
            temp_file.unlink(missing_ok=True)

        self.send_response(HTTPStatus.SEE_OTHER)
        redirect = target.as_posix()
        self.send_header("Location", f"/?path={redirect}" if redirect else "/")
        self.end_headers()

    def _handle_download(self, target: Path):
        try:
            path = self.storage.open_file(target)
        except FileNotFoundError:
            self.send_error(HTTPStatus.NOT_FOUND, "File not found")
            return

        mime_type, _ = mimetypes.guess_type(str(path))
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", mime_type or "application/octet-stream")
        self.send_header("Content-Disposition", f"attachment; filename=\"{path.name}\"")
        self.send_header("Content-Length", str(path.stat().st_size))
        self.end_headers()
        with path.open("rb") as file_obj:
            copyfileobj(file_obj, self.wfile)

    def _handle_api_list(self, target: Path):
        try:
            items = list(self.storage.list(target))
        except (FileNotFoundError, ValueError):
            self.send_error(HTTPStatus.NOT_FOUND, "Path not found")
            return

        payload = {
            "path": target.as_posix(),
            "items": [
                {
                    "name": item.name,
                    "path": item.path.as_posix(),
                    "isDir": item.is_dir,
                    "size": item.size,
                    "sizeDisplay": item.size_display,
                }
                for item in items
            ],
        }

        body = json.dumps(payload).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def _serve_static(self):
        relative = url_to_path(self.path[len("/static/"):])
        file_path = (self.static_root / relative).resolve()
        if not str(file_path).startswith(str(self.static_root)) or not file_path.exists():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        mime_type, _ = mimetypes.guess_type(str(file_path))
        data = file_path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", mime_type or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _query_params(self) -> dict[str, str]:
        parsed = urlparse(self.path)
        return {k: v[0] for k, v in parse_qs(parsed.query, keep_blank_values=True).items() if v}


def run_server(config: Config):
    from http.server import ThreadingHTTPServer

    def handler(*args, **kwargs):
        return NShareRequestHandler(*args, config=config, **kwargs)

    server_address = (config.host, config.port)
    httpd = ThreadingHTTPServer(server_address, handler)

    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    lan_ip = get_lan_ip()
    logging.info(
        "Serving on http://%s:%s (LAN: http://%s:%s)",
        config.host,
        config.port,
        lan_ip,
        config.port,
    )
    return thread, httpd


def url_to_path(value: str) -> str:
    return unquote(value).lstrip("/")


