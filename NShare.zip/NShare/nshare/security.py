"""Security helpers for NShare."""

from __future__ import annotations

import secrets
from functools import wraps
from typing import Callable, Optional


def generate_csrf_token(length: int = 32) -> str:
    return secrets.token_urlsafe(length)


def require_token(expected_token: Optional[str]):
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(handler, *args, **kwargs):
            if expected_token is None:
                return func(handler, *args, **kwargs)

            provided = handler.headers.get("Authorization")
            if provided and provided.startswith("Bearer "):
                token = provided.split(" ", 1)[1]
            else:
                token = handler.get_token_from_request()

            if secrets.compare_digest(token or "", expected_token):
                return func(handler, *args, **kwargs)

            handler.send_response(401)
            handler.send_header("WWW-Authenticate", "Bearer")
            handler.end_headers()
            handler.wfile.write(b"Unauthorized")

        return wrapper

    return decorator
