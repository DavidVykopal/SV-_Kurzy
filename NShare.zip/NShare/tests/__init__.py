"""Test package for NShare."""
